/* eslint-disable prettier/prettier */
/* eslint-disable react/self-closing-comp */
import React from "react";

const addEmployee = () => <div>
    Bhawna Chaudhry
</div>;

export default addEmployee;
